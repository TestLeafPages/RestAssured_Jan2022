package steps;

import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class baseAPI {
	public static Response response;
	public static ValidatableResponse json;
	public static RequestSpecification request;
}
